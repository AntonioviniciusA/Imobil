package com.example.imobil.Activity;
import android.os.Bundle;
import com.example.imobil.R;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivityImobiliaria extends AppCompatActivity  {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_principal_imobiliaria);


    }

}
