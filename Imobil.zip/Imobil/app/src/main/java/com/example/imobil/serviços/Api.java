package com.example.imobil.serviços;

public class Api {
}
